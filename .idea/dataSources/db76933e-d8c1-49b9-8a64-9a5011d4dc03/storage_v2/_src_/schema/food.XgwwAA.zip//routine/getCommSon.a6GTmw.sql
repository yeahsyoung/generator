create
    definer = zhimao@`%` procedure getCommSon(IN comm_user bigint, IN order_user bigint)
    comment '查询被分佣用户的直属一级下属（用户哪一条线给他产生的分佣）'
BEGIN
	DECLARE i BIGINT;
	DECLARE j BIGINT;
	IF (comm_user IS NOT NULL AND order_user IS NOT NULL) THEN
		SET i = order_user;
				REPEAT
					SET j = i;
					SELECT inviter_id INTO i FROM act_invite WHERE invitee_id = j;
				UNTIL (i = comm_user OR i IS NULL)
				END REPEAT;
	END IF;
	SELECT j;
END;

