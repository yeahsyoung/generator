create view receivablesview as
select `a`.`receivables_id`    AS `receivables_id`,
       `a`.`number`            AS `number`,
       `a`.`plan_id`           AS `plan_id`,
       `a`.`customer_id`       AS `customer_id`,
       `a`.`contract_id`       AS `contract_id`,
       `a`.`check_status`      AS `check_status`,
       `a`.`examine_record_id` AS `examine_record_id`,
       `a`.`return_time`       AS `return_time`,
       `a`.`return_type`       AS `return_type`,
       `a`.`money`             AS `money`,
       `a`.`remark`            AS `remark`,
       `a`.`create_user_id`    AS `create_user_id`,
       `a`.`owner_user_id`     AS `owner_user_id`,
       `a`.`create_time`       AS `create_time`,
       `a`.`update_time`       AS `update_time`,
       `a`.`remarks`           AS `remarks`,
       `a`.`batch_id`          AS `batch_id`,
       `b`.`realname`          AS `create_user_name`,
       `c`.`realname`          AS `owner_user_name`,
       `d`.`customer_name`     AS `customer_name`,
       `e`.`name`              AS `contract_name`,
       `e`.`num`               AS `contract_num`,
       `f`.`num`               AS `plan_num`,
       (select `crm9`.`72crm_admin_field`.`value`
        from `crm9`.`72crm_admin_field`
        where ((`crm9`.`72crm_admin_field`.`name` = '回款方式') and
               (`crm9`.`72crm_admin_field`.`batch_id` = convert(`a`.`batch_id` using utf8mb4)))
        limit 1)               AS `回款方式`
from (((((`crm9`.`72crm_crm_receivables` `a` left join `crm9`.`72crm_admin_user` `b` on ((`a`.`create_user_id` = `b`.`user_id`))) left join `crm9`.`72crm_admin_user` `c` on ((`a`.`owner_user_id` = `c`.`user_id`))) left join `crm9`.`72crm_crm_customer` `d` on ((`a`.`customer_id` = `d`.`customer_id`))) left join `crm9`.`72crm_crm_contract` `e` on ((`a`.`contract_id` = `e`.`contract_id`)))
         left join `crm9`.`72crm_crm_receivables_plan` `f` on ((`a`.`plan_id` = `f`.`plan_id`)));

