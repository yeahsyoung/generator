create view customerview as
select `a`.`customer_id`    AS `customer_id`,
       `a`.`customer_name`  AS `customer_name`,
       `a`.`is_lock`        AS `is_lock`,
       `a`.`next_time`      AS `next_time`,
       `a`.`deal_status`    AS `deal_status`,
       `a`.`telephone`      AS `telephone`,
       `a`.`website`        AS `website`,
       `a`.`remark`         AS `remark`,
       `a`.`create_user_id` AS `create_user_id`,
       `a`.`owner_user_id`  AS `owner_user_id`,
       `a`.`ro_user_id`     AS `ro_user_id`,
       `a`.`rw_user_id`     AS `rw_user_id`,
       `a`.`address`        AS `address`,
       `a`.`location`       AS `location`,
       `a`.`detail_address` AS `detail_address`,
       `a`.`lng`            AS `lng`,
       `a`.`lat`            AS `lat`,
       `a`.`create_time`    AS `create_time`,
       `a`.`update_time`    AS `update_time`,
       `a`.`batch_id`       AS `batch_id`,
       `b`.`realname`       AS `create_user_name`,
       `c`.`realname`       AS `owner_user_name`,
       (select `crm9`.`72crm_admin_field`.`value`
        from `crm9`.`72crm_admin_field`
        where ((`crm9`.`72crm_admin_field`.`name` = '客户级别') and
               (`crm9`.`72crm_admin_field`.`batch_id` = convert(`a`.`batch_id` using utf8mb4)))
        limit 1)            AS `客户级别`,
       (select `crm9`.`72crm_admin_field`.`value`
        from `crm9`.`72crm_admin_field`
        where ((`crm9`.`72crm_admin_field`.`name` = '客户来源') and
               (`crm9`.`72crm_admin_field`.`batch_id` = convert(`a`.`batch_id` using utf8mb4)))
        limit 1)            AS `客户来源`,
       (select `crm9`.`72crm_admin_field`.`value`
        from `crm9`.`72crm_admin_field`
        where ((`crm9`.`72crm_admin_field`.`name` = '客户行业') and
               (`crm9`.`72crm_admin_field`.`batch_id` = convert(`a`.`batch_id` using utf8mb4)))
        limit 1)            AS `客户行业`
from ((`crm9`.`72crm_crm_customer` `a` left join `crm9`.`72crm_admin_user` `b` on ((`a`.`create_user_id` = `b`.`user_id`)))
         left join `crm9`.`72crm_admin_user` `c` on ((`a`.`owner_user_id` = `c`.`user_id`)));

