create view contractview as
select `a`.`contract_id`                                         AS `contract_id`,
       `a`.`name`                                                AS `name`,
       `a`.`customer_id`                                         AS `customer_id`,
       `a`.`business_id`                                         AS `business_id`,
       `a`.`check_status`                                        AS `check_status`,
       `a`.`examine_record_id`                                   AS `examine_record_id`,
       `a`.`order_date`                                          AS `order_date`,
       `a`.`create_user_id`                                      AS `create_user_id`,
       `a`.`owner_user_id`                                       AS `owner_user_id`,
       `a`.`create_time`                                         AS `create_time`,
       `a`.`update_time`                                         AS `update_time`,
       `a`.`num`                                                 AS `num`,
       `a`.`start_time`                                          AS `start_time`,
       `a`.`end_time`                                            AS `end_time`,
       `a`.`money`                                               AS `money`,
       `a`.`discount_rate`                                       AS `discount_rate`,
       `a`.`types`                                               AS `types`,
       `a`.`payment_type`                                        AS `payment_type`,
       `a`.`batch_id`                                            AS `batch_id`,
       `a`.`ro_user_id`                                          AS `ro_user_id`,
       `a`.`rw_user_id`                                          AS `rw_user_id`,
       `a`.`contacts_id`                                         AS `contacts_id`,
       `a`.`remark`                                              AS `remark`,
       `a`.`company_user_id`                                     AS `company_user_id`,
       `b`.`realname`                                            AS `create_user_name`,
       `c`.`realname`                                            AS `owner_user_name`,
       `d`.`customer_name`                                       AS `customer_name`,
       `e`.`business_name`                                       AS `business_name`,
       `f`.`name`                                                AS `contacts_name`,
       `g`.`realname`                                            AS `company_user_name`,
       (select `crm9`.`72crm_admin_dept`.`name`
        from `crm9`.`72crm_admin_dept`
        where (`crm9`.`72crm_admin_dept`.`dept_id` = (select `crm9`.`72crm_admin_field`.`value`
                                                      from `crm9`.`72crm_admin_field`
                                                      where ((`crm9`.`72crm_admin_field`.`name` = '部门') and
                                                             (`crm9`.`72crm_admin_field`.`batch_id` =
                                                              convert(`a`.`batch_id` using utf8mb4)))
                                                      limit 1))) AS `部门`
from ((((((`crm9`.`72crm_crm_contract` `a` left join `crm9`.`72crm_admin_user` `b` on ((`a`.`create_user_id` = `b`.`user_id`))) left join `crm9`.`72crm_admin_user` `c` on ((`a`.`owner_user_id` = `c`.`user_id`))) left join `crm9`.`72crm_crm_customer` `d` on ((`a`.`customer_id` = `d`.`customer_id`))) left join `crm9`.`72crm_crm_business` `e` on ((`a`.`business_id` = `e`.`business_id`))) left join `crm9`.`72crm_crm_contacts` `f` on ((`a`.`contacts_id` = `f`.`contacts_id`)))
         left join `crm9`.`72crm_admin_user` `g` on ((`a`.`company_user_id` = `g`.`user_id`)));

