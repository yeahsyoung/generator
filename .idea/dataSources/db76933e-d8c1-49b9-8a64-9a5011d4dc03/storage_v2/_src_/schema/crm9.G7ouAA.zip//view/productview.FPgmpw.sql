create view productview as
select `a`.`product_id`     AS `product_id`,
       `a`.`name`           AS `name`,
       `a`.`num`            AS `num`,
       `a`.`unit`           AS `unit`,
       `a`.`price`          AS `price`,
       `a`.`status`         AS `status`,
       `a`.`category_id`    AS `category_id`,
       `a`.`description`    AS `description`,
       `a`.`create_user_id` AS `create_user_id`,
       `a`.`owner_user_id`  AS `owner_user_id`,
       `a`.`create_time`    AS `create_time`,
       `a`.`update_time`    AS `update_time`,
       `a`.`batch_id`       AS `batch_id`,
       `b`.`realname`       AS `create_user_name`,
       `c`.`realname`       AS `owner_user_name`,
       `d`.`name`           AS `category_name`,
       (select `crm9`.`72crm_admin_field`.`value`
        from `crm9`.`72crm_admin_field`
        where ((`crm9`.`72crm_admin_field`.`name` = '是否上下架') and
               (`crm9`.`72crm_admin_field`.`batch_id` = convert(`a`.`batch_id` using utf8mb4)))
        limit 1)            AS `是否上下架`,
       (select `crm9`.`72crm_admin_field`.`value`
        from `crm9`.`72crm_admin_field`
        where ((`crm9`.`72crm_admin_field`.`name` = '单位') and
               (`crm9`.`72crm_admin_field`.`batch_id` = convert(`a`.`batch_id` using utf8mb4)))
        limit 1)            AS `单位`,
       (select `crm9`.`72crm_admin_field`.`value`
        from `crm9`.`72crm_admin_field`
        where ((`crm9`.`72crm_admin_field`.`name` = '产品颜色') and
               (`crm9`.`72crm_admin_field`.`batch_id` = convert(`a`.`batch_id` using utf8mb4)))
        limit 1)            AS `产品颜色`
from (((`crm9`.`72crm_crm_product` `a` left join `crm9`.`72crm_admin_user` `b` on ((`a`.`create_user_id` = `b`.`user_id`))) left join `crm9`.`72crm_admin_user` `c` on ((`a`.`owner_user_id` = `c`.`user_id`)))
         left join `crm9`.`72crm_crm_product_category` `d` on ((`a`.`category_id` = `d`.`category_id`)));

