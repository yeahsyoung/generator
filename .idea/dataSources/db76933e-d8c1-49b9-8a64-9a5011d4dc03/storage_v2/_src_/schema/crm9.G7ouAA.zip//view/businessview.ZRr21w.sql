create view businessview as
select `a`.`business_id`    AS `business_id`,
       `a`.`type_id`        AS `type_id`,
       `a`.`status_id`      AS `status_id`,
       `a`.`next_time`      AS `next_time`,
       `a`.`customer_id`    AS `customer_id`,
       `a`.`deal_date`      AS `deal_date`,
       `a`.`business_name`  AS `business_name`,
       `a`.`money`          AS `money`,
       `a`.`discount_rate`  AS `discount_rate`,
       `a`.`remark`         AS `remark`,
       `a`.`create_user_id` AS `create_user_id`,
       `a`.`owner_user_id`  AS `owner_user_id`,
       `a`.`create_time`    AS `create_time`,
       `a`.`update_time`    AS `update_time`,
       `a`.`batch_id`       AS `batch_id`,
       `a`.`ro_user_id`     AS `ro_user_id`,
       `a`.`rw_user_id`     AS `rw_user_id`,
       `a`.`is_end`         AS `is_end`,
       `a`.`status_remark`  AS `status_remark`,
       `b`.`realname`       AS `create_user_name`,
       `c`.`realname`       AS `owner_user_name`,
       `d`.`customer_name`  AS `customer_name`,
       `e`.`name`           AS `type_name`,
       `f`.`name`           AS `status_name`
from (((((`crm9`.`72crm_crm_business` `a` left join `crm9`.`72crm_admin_user` `b` on ((`a`.`create_user_id` = `b`.`user_id`))) left join `crm9`.`72crm_admin_user` `c` on ((`a`.`owner_user_id` = `c`.`user_id`))) left join `crm9`.`72crm_crm_customer` `d` on ((`a`.`customer_id` = `d`.`customer_id`))) left join `crm9`.`72crm_crm_business_type` `e` on ((`a`.`type_id` = `e`.`type_id`)))
         left join `crm9`.`72crm_crm_business_status` `f` on ((`a`.`status_id` = `f`.`status_id`)));

