create view contactsview as
select `a`.`contacts_id`    AS `contacts_id`,
       `a`.`name`           AS `name`,
       `a`.`next_time`      AS `next_time`,
       `a`.`mobile`         AS `mobile`,
       `a`.`telephone`      AS `telephone`,
       `a`.`email`          AS `email`,
       `a`.`post`           AS `post`,
       `a`.`customer_id`    AS `customer_id`,
       `a`.`address`        AS `address`,
       `a`.`remark`         AS `remark`,
       `a`.`create_user_id` AS `create_user_id`,
       `a`.`owner_user_id`  AS `owner_user_id`,
       `a`.`create_time`    AS `create_time`,
       `a`.`update_time`    AS `update_time`,
       `a`.`batch_id`       AS `batch_id`,
       `a`.`name`           AS `contacts_name`,
       `b`.`realname`       AS `create_user_name`,
       `c`.`realname`       AS `owner_user_name`,
       `d`.`customer_name`  AS `customer_name`,
       (select `crm9`.`72crm_admin_field`.`value`
        from `crm9`.`72crm_admin_field`
        where ((`crm9`.`72crm_admin_field`.`name` = '是否关键决策人') and
               (`crm9`.`72crm_admin_field`.`batch_id` = convert(`a`.`batch_id` using utf8mb4)))
        limit 1)            AS `是否关键决策人`,
       (select `crm9`.`72crm_admin_field`.`value`
        from `crm9`.`72crm_admin_field`
        where ((`crm9`.`72crm_admin_field`.`name` = '性别') and
               (`crm9`.`72crm_admin_field`.`batch_id` = convert(`a`.`batch_id` using utf8mb4)))
        limit 1)            AS `性别`
from (((`crm9`.`72crm_crm_contacts` `a` left join `crm9`.`72crm_admin_user` `b` on ((`a`.`create_user_id` = `b`.`user_id`))) left join `crm9`.`72crm_admin_user` `c` on ((`a`.`owner_user_id` = `c`.`user_id`)))
         left join `crm9`.`72crm_crm_customer` `d` on ((`a`.`customer_id` = `d`.`customer_id`)));

